<?php 
session_start();
include('header.php'); 
?>

<style>
  html, body {
    height: 100%;
    margin: 0;
  }
  .wrapper {
    min-height: 100%;
    display: flex;
    flex-direction: column;
  }
  .content-wrapper {
    flex: 1;
  }

  .content-wrapper {
    min-height: 0 !important;
  }


</style>

<body class="hold-transition layout-top-nav">
<div class="wrapper">

  <!-- Navbar -->
  <?php include('topbar.php') ?>
  <!-- /.navbar -->

  <!-- Content Wrapper -->
  <div class="content-wrapper">
    <!-- Main content -->
    <div class="content py-4">
      <div class="container">
        <div class="d-flex justify-content-center">
          <div style="background: #1e1e1e; color: #fff; border-radius: 15px; box-shadow: 0 0 15px rgba(255, 255, 255, 0.1); padding: 30px; max-width: 700px; text-align: center;">
            <img src="assets/dist/img/Prakash.jpg" alt="Prakash Kashinath Pisal" style="width: 150px; height: 150px; border-radius: 50%; border: 4px solid #c4913f; margin-bottom: 20px;">
            <h2 style="color: #c4913f;">Prakash Kashinath Pisal</h2>
            <p style="font-size: 16px;">Owner of Swapna Nagari Publication, Sai Store, and Swapna Nagari Jewellers.</p>
            <p style="text-align: justify; font-size: 15px; line-height: 1.6;">
              With years of experience in business, he has successfully established multiple ventures, serving customers with trust and excellence. 
              <strong>Swapna Nagari Jewellers</strong> is renowned for its craftsmanship and dedication to quality. With a commitment to creating exquisite and timeless designs, the brand blends traditional artistry with modern elegance. 
              Every piece is crafted with precision, ensuring superior quality and customer satisfaction, making it a trusted name in the world of fine jewelry.
            </p>
            <p style="font-weight: bold; margin-top: 20px;">Swapna Nagari Jewellers Address:</p>
            <p>Near Town Hall, Karad, Satara – 415110</p>
            <p><strong>Contact:</strong> 9823631097</p>
            <p><strong>Email:</strong> <a href="mailto:prakash.pisal@gmail.com" style="color: #c4913f;">prakash.pisal@gmail.com</a></p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /.content-wrapper -->

  <?php include('footer.php') ?>

</div>
<!-- ./wrapper -->

<!-- Scripts -->
<script src="../assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../assets/dist/js/adminlte.js"></script>
</body>
</html>
