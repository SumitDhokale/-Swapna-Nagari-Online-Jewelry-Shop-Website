<?php
include 'db_connect.php';
include 'header.php';
include 'topbar.php';
include 'sidebar.php';
?>

<div class="content-wrapper">
  <div class="content-header">
    <h1 class="m-0">User Feedback</h1>
  </div>
  
  <div class="content">
    <div class="card">
      <div class="card-body">
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Message</th>
              <th>Submitted At</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $query = $conn->query("SELECT * FROM feedback ORDER BY created_at DESC");
            while($row = $query->fetch_assoc()):
            ?>
              <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td><?php echo htmlspecialchars($row['email']); ?></td>
                <td><?php echo nl2br(htmlspecialchars($row['message'])); ?></td>
                <td><?php echo $row['created_at']; ?></td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>
